[['text'=>"Add Accounts", 'callback_data'=>'shs']],
['text'=>"Geting users", 'callback_data'=>'get']],
[['text'=>"Start Checking", 'callback_data'=>'pro'],['text'=>"Stop Checking", 'callback_data'=>'hoom']],
[['text'=>"Add Sleep", 'callback_data'=>'sleep']],



[['text'=>"تسجيل دخول", 'callback_data'=>'shs']],
['text'=>"طرق تخمين", 'callback_data'=>'get']],
[['text'=>"بدأ التخمين", 'callback_data'=>'pro'],['text'=>"أيقاف التخمين", 'callback_data'=>'hoom']],
[['text'=>"تحديد السرعه", 'callback_data'=>'sleep']],



[['text'=>"Login", 'callback_data'=>'shs']],
['text'=>"Check users", 'callback_data'=>'get']],
[['text'=>"on bot", 'callback_data'=>'pro'],['text'=>"off bot", 'callback_data'=>'hoom']],
[['text'=>"my speed", 'callback_data'=>'sleep']],




اهلا بك عزيزي في بوت الصيد الخاص بك
~ by : @YYYhYY



hi sir in bot checked privet you iG
~ by : @YYYhYY


⚠️♻️💙🚫🖤👍👍🔽😐👆🥺😂💽⚓😭👇😀🏴🤪👈